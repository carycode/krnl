var dir_d627bce0ed207092036ea651c512d3ca =
[
    [ "krnltaskshifttime.ino", "krnltaskshifttime_8ino.html", "krnltaskshifttime_8ino" ]
];