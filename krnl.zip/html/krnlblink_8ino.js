var krnlblink_8ino =
[
    [ "loop", "krnlblink_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "krnlblink_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "t1", "krnlblink_8ino.html#a78ed8c1d641408a085543aa2d77ed93f", null ],
    [ "p", "krnlblink_8ino.html#a745b382939ac8265c4ddc1edaaa69c8e", null ],
    [ "stak", "krnlblink_8ino.html#a3bf7d82d708cc10a714f9c15afad58c9", null ]
];