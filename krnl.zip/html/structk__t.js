var structk__t =
[
    [ "clip", "structk__t.html#ad58455e7feb435218e12629a6b8321b9", null ],
    [ "cnt1", "structk__t.html#a7ef04bafaf2e57965dfa0c8a1d14d124", null ],
    [ "cnt2", "structk__t.html#a7ae00f43d917f25200fffd1a8defe5ef", null ],
    [ "cnt3", "structk__t.html#aec4d7232788478d29abb708ca07f6796", null ],
    [ "maxv", "structk__t.html#ab5c4013797f848b7f3d306c8b12375b0", null ],
    [ "next", "structk__t.html#ab1bd22ca23083ad81771ed998437fdfc", null ],
    [ "nr", "structk__t.html#abc0705694abb02c6005759d8ba66f35e", null ],
    [ "pred", "structk__t.html#a600d8611c0af5f63b647ab12d219e0fb", null ],
    [ "prio", "structk__t.html#a024120239a208b97bf2fcd17b9534182", null ],
    [ "sp_hi", "structk__t.html#acb129ee9a4e02ae9c68d07c72c0db02d", null ],
    [ "sp_lo", "structk__t.html#a1e6a2845b26a85e548e64a8ae310d7ac", null ]
];