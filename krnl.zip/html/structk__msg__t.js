var structk__msg__t =
[
    [ "cnt", "structk__msg__t.html#afffaeebfdb8d84f296755babf6f296a6", null ],
    [ "el_size", "structk__msg__t.html#a9e6cf0aaaa54e2c69938457b2a16e512", null ],
    [ "lost_msg", "structk__msg__t.html#aea9315f70a4c165cf9bfaef79046c184", null ],
    [ "nr", "structk__msg__t.html#a77ce5d05e251d771c3bbdc4ca724cbf7", null ],
    [ "nr_el", "structk__msg__t.html#ae28a828860fdf0afcd9106045d223767", null ],
    [ "pBuf", "structk__msg__t.html#ac1285a0d8e7c3925b8f7671d92553ef7", null ],
    [ "r", "structk__msg__t.html#aac75863785b0f241b90e49b440f9cd4a", null ],
    [ "sem", "structk__msg__t.html#abc38d50a3f77336df86ddc6a55665c0e", null ],
    [ "w", "structk__msg__t.html#ad7653be9d894a288d863062258a6c467", null ]
];