var annotated =
[
    [ "k_msg_t", "structk__msg__t.html", "structk__msg__t" ],
    [ "k_t", "structk__t.html", "structk__t" ]
];