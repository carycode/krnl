var k00readme_8ino =
[
    [ "hacking", "k00readme_8ino.html#a94decdc1d4443e1def9080ff488f7339", null ],
    [ "k01", "k00readme_8ino.html#adc046d06cab431db0dde51884db396e2", null ]
];