var krnlisrsemkick_8ino =
[
    [ "STK_SIZE", "krnlisrsemkick_8ino.html#a4740d21ee60d610e9f41b418b0381574", null ],
    [ "doBlink", "krnlisrsemkick_8ino.html#a324b3fb0f00dc6c117e43c2457b769df", null ],
    [ "initISR", "krnlisrsemkick_8ino.html#a92300647f16bcc09c77b63fff729b75a", null ],
    [ "ISR", "krnlisrsemkick_8ino.html#acf4b084ca17c36c70fb550b2d327e8f8", null ],
    [ "loop", "krnlisrsemkick_8ino.html#a0b33edabd7f1c4e4a0bf32c67269be2f", null ],
    [ "setup", "krnlisrsemkick_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "t1", "krnlisrsemkick_8ino.html#ac5c5136eb2c6e01ac014c723c5be421f", null ],
    [ "t2", "krnlisrsemkick_8ino.html#a76cb230c0ffd18dba5932a1677e6866a", null ],
    [ "icnt", "krnlisrsemkick_8ino.html#ae9258a2b826681fce2e890dd06eb6b5a", null ],
    [ "p_t1", "krnlisrsemkick_8ino.html#a6b49d0ca65b78fc8332de763ed646f34", null ],
    [ "p_t2", "krnlisrsemkick_8ino.html#ac5ebea1b0a546eeff4049d2124df839f", null ],
    [ "s1", "krnlisrsemkick_8ino.html#a30ae708e836c1f1f19141fe2b8c41bdc", null ],
    [ "s2", "krnlisrsemkick_8ino.html#a7e329f1066206e7faf9161f87b91a717", null ],
    [ "sem1", "krnlisrsemkick_8ino.html#a10808bb48fa0ad1f2cb5e2a020b5245e", null ]
];