var myfirst_8ino =
[
    [ "code", "myfirst_8ino.html#aa79159d6045479641ec1c1d0f67d7cb9", null ],
    [ "loop", "myfirst_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "myfirst_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "pTaskInfo", "myfirst_8ino.html#a92fcb9ace6f2c9861932e9a5c0c81f6f", null ],
    [ "stak", "myfirst_8ino.html#a3bf7d82d708cc10a714f9c15afad58c9", null ]
];