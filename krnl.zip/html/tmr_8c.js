var tmr_8c =
[
    [ "DIV16", "tmr_8c.html#a7b472b601b667cd41031f57c8290527d", null ],
    [ "DIV8", "tmr_8c.html#a89ca63a5f13df426cd5c4f025eefef48", null ],
    [ "KRNLTMRVECTOR", "tmr_8c.html#a8390550b01018588df23043e908ded51", null ],
    [ "OCRxA", "tmr_8c.html#a8d7bc6726e0fd85c5873faeb6e4246f9", null ],
    [ "TCCRxA", "tmr_8c.html#aedef1a8b3de29d96e6f2e152ccfe2a26", null ],
    [ "TCCRxB", "tmr_8c.html#a1898265baad35102ca5d950b41e7dc1a", null ],
    [ "TCNTx", "tmr_8c.html#a6e681752552f535dfb234bf75808e2a1", null ],
    [ "TCNTx", "tmr_8c.html#a6e681752552f535dfb234bf75808e2a1", null ],
    [ "TIMSKx", "tmr_8c.html#a1e363f21cd8c0e899bbe4d9908466375", null ],
    [ "TOIEx", "tmr_8c.html#a6e9792cc10d49106aa9bfac11ab374bc", null ],
    [ "ISR", "tmr_8c.html#a3bde43696cb215a820071add04d83139", null ],
    [ "tmrr_start", "tmr_8c.html#a2b147b22bea8489ec45b9f79c491a679", null ],
    [ "tcntValue", "tmr_8c.html#a4b4a047399e1ee15b40777542d354b52", null ]
];