var searchData=
[
  ['sem_5fmax_5fdefault',['SEM_MAX_DEFAULT',['../krnl_8h.html#a1b16bb6a333404e2357226454a592f6e',1,'krnl.h']]],
  ['stak_5fhash',['STAK_HASH',['../krnl_8h.html#ae0f7f3fba8495af1a0d053fc1806bc09',1,'krnl.h']]],
  ['stk',['STK',['../k11breakout_clip_8ino.html#abbfd9a2b36c64f065ab28c8330bc5010',1,'k11breakoutClip.ino']]],
  ['stk_5fsize',['STK_SIZE',['../krnlisrsemkick_8ino.html#a4740d21ee60d610e9f41b418b0381574',1,'STK_SIZE():&#160;krnlisrsemkick.ino'],['../krnlisrsemkick_ard_8ino.html#a4740d21ee60d610e9f41b418b0381574',1,'STK_SIZE():&#160;krnlisrsemkickArd.ino'],['../krnltaskshifttime_8ino.html#a4740d21ee60d610e9f41b418b0381574',1,'STK_SIZE():&#160;krnltaskshifttime.ino'],['../msgtstisrsimple_8ino.html#a4740d21ee60d610e9f41b418b0381574',1,'STK_SIZE():&#160;msgtstisrsimple.ino'],['../msgtstisrsimplenoglitch_8ino.html#a4740d21ee60d610e9f41b418b0381574',1,'STK_SIZE():&#160;msgtstisrsimplenoglitch.ino']]]
];
