var searchData=
[
  ['ocrxa',['OCRxA',['../krnl_8c.html#a8d7bc6726e0fd85c5873faeb6e4246f9',1,'krnl.c']]]
];
