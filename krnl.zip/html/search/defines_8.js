var searchData=
[
  ['popregs',['POPREGS',['../krnl_8h.html#a170526ca75023d4bb1046e3b0988f6c0',1,'krnl.h']]],
  ['prescale',['PRESCALE',['../krnl_8c.html#ab27d12aac1a3a46aed25604d4c00cc18',1,'krnl.c']]],
  ['pushregs',['PUSHREGS',['../krnl_8h.html#a3ba7acce9c4a4348a166afaa07981bdc',1,'krnl.h']]]
];
