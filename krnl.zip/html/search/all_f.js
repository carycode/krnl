var searchData=
[
  ['r',['r',['../structk__msg__t.html#aac75863785b0f241b90e49b440f9cd4a',1,'k_msg_t']]],
  ['reti',['RETI',['../krnl_8h.html#a8513872c337c84cc24af517c5ef3605a',1,'krnl.h']]]
];
