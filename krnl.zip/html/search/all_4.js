var searchData=
[
  ['edf',['EDF',['../krnl_8h.html#a598ea65f0a8f860fc7e16343fe1851a1',1,'krnl.h']]],
  ['edf_5fprio_5flimit',['EDF_PRIO_LIMIT',['../krnl_8h.html#a63b2bfede59af539d310ff9ee544e10f',1,'krnl.h']]],
  ['ei',['EI',['../krnl_8h.html#a54322f0fb4209b096e8e3b5864b46875',1,'krnl.h']]],
  ['el_5fsize',['el_size',['../structk__msg__t.html#a9e6cf0aaaa54e2c69938457b2a16e512',1,'k_msg_t']]],
  ['enq',['enQ',['../krnl_8c.html#ab750c904258e717b40c17f55400ca3b2',1,'krnl.c']]]
];
