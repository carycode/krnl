var searchData=
[
  ['hacking',['hacking',['../k00readme_8ino.html#a94decdc1d4443e1def9080ff488f7339',1,'k00readme.ino']]]
];
