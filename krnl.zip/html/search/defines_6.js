var searchData=
[
  ['main_5fprio',['MAIN_PRIO',['../krnl_8h.html#add243159986ad4ecae03a1e77c9dea6c',1,'krnl.h']]],
  ['max_5fint',['MAX_INT',['../krnl_8h.html#aaa1ac5caef84256eaeb39594e58e096f',1,'krnl.h']]],
  ['max_5fsem_5fval',['MAX_SEM_VAL',['../krnl_8h.html#afe39f29482489a949f24b4f4de6e9163',1,'krnl.h']]]
];
