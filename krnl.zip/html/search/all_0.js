var searchData=
[
  ['_5f_5fattribute_5f_5f',['__attribute__',['../krnl_8c.html#ab04f0f0b9eae773e634b2af977e882a9',1,'__attribute__((naked, noinline)):&#160;krnl.c'],['../krnl_8h.html#afd53aa13189bcd9d4d4b5007042c0dde',1,'__attribute__((weak)) k_sem_clip(unsigned char nr:&#160;krnl.h']]]
];
