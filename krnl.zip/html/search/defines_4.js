var searchData=
[
  ['k_5fchg_5fstak',['K_CHG_STAK',['../krnl_8h.html#ab1d7cfc61583d7b1abf379373daeeccc',1,'krnl.h']]],
  ['krnl_5fvrs',['KRNL_VRS',['../krnl_8h.html#a9af27293504cc2ad16bdbd062abe834e',1,'krnl.h']]],
  ['krnlbug',['KRNLBUG',['../krnl_8h.html#a6d7c92c551defd0d0764df90a09cea03',1,'krnl.h']]],
  ['krnltmr',['KRNLTMR',['../krnl_8h.html#ad0559cb6857c3d0c63f0353b5828a2af',1,'krnl.h']]],
  ['krnltmrvector',['KRNLTMRVECTOR',['../krnl_8c.html#a8390550b01018588df23043e908ded51',1,'krnl.c']]]
];
