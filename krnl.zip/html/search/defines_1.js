var searchData=
[
  ['di',['DI',['../krnl_8h.html#a087fe5231de92285218140559b5b7886',1,'krnl.h']]],
  ['divv',['DIVV',['../krnl_8c.html#a734615b1179c3466e4cee6d7777ff3a1',1,'krnl.c']]],
  ['divv8',['DIVV8',['../krnl_8c.html#a1e55b17b4f68107071bec1eb064edb66',1,'krnl.c']]],
  ['dmy_5fprio',['DMY_PRIO',['../krnl_8h.html#acf2f4a8f04e484305e7c862c0cb39d63',1,'krnl.h']]],
  ['dmy_5fstk_5fsz',['DMY_STK_SZ',['../krnl_8h.html#a1159800af031443d866b321adaae60d8',1,'krnl.h']]]
];
