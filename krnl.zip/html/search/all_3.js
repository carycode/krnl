var searchData=
[
  ['deq',['deQ',['../krnl_8c.html#a7ac8496c83319bfc569e4fdab8149940',1,'krnl.c']]],
  ['di',['DI',['../krnl_8h.html#a087fe5231de92285218140559b5b7886',1,'krnl.h']]],
  ['divv',['DIVV',['../krnl_8c.html#a734615b1179c3466e4cee6d7777ff3a1',1,'krnl.c']]],
  ['divv8',['DIVV8',['../krnl_8c.html#a1e55b17b4f68107071bec1eb064edb66',1,'krnl.c']]],
  ['dmy_5fprio',['DMY_PRIO',['../krnl_8h.html#acf2f4a8f04e484305e7c862c0cb39d63',1,'krnl.h']]],
  ['dmy_5fstk',['dmy_stk',['../krnl_8h.html#a38effc60e299ca322c0065e67270a933',1,'krnl.h']]],
  ['dmy_5fstk_5fsz',['DMY_STK_SZ',['../krnl_8h.html#a1159800af031443d866b321adaae60d8',1,'krnl.h']]],
  ['doblink',['doBlink',['../krnlisrsemkick_8ino.html#a324b3fb0f00dc6c117e43c2457b769df',1,'doBlink(void):&#160;krnlisrsemkick.ino'],['../krnlisrsemkick_ard_8ino.html#a324b3fb0f00dc6c117e43c2457b769df',1,'doBlink(void):&#160;krnlisrsemkickArd.ino'],['../msgtstisrsimple_8ino.html#a324b3fb0f00dc6c117e43c2457b769df',1,'doBlink(void):&#160;msgtstisrsimple.ino'],['../msgtstisrsimplenoglitch_8ino.html#a324b3fb0f00dc6c117e43c2457b769df',1,'doBlink(void):&#160;msgtstisrsimplenoglitch.ino'],['../semmutex_8ino.html#a324b3fb0f00dc6c117e43c2457b769df',1,'doBlink(void):&#160;semmutex.ino'],['../semsync_8ino.html#a324b3fb0f00dc6c117e43c2457b769df',1,'doBlink(void):&#160;semsync.ino'],['../timedsem_8ino.html#a324b3fb0f00dc6c117e43c2457b769df',1,'doBlink(void):&#160;timedsem.ino']]]
];
