var searchData=
[
  ['next',['next',['../structk__t.html#ab1bd22ca23083ad81771ed998437fdfc',1,'k_t']]],
  ['nowisr',['nowISR',['../msgtstisrsimplenoglitch_8ino.html#a394bbc77995fcc53069462b1878f9835',1,'msgtstisrsimplenoglitch.ino']]],
  ['nr',['nr',['../structk__t.html#abc0705694abb02c6005759d8ba66f35e',1,'k_t::nr()'],['../structk__msg__t.html#a77ce5d05e251d771c3bbdc4ca724cbf7',1,'k_msg_t::nr()']]],
  ['nr_5fel',['nr_el',['../structk__msg__t.html#ae28a828860fdf0afcd9106045d223767',1,'k_msg_t']]],
  ['nr_5fsem',['nr_sem',['../krnl_8c.html#a836f47dd0a5450a93da2951223de72ef',1,'nr_sem():&#160;krnl.c'],['../krnl_8h.html#a836f47dd0a5450a93da2951223de72ef',1,'nr_sem():&#160;krnl.c']]],
  ['nr_5fsend',['nr_send',['../krnl_8c.html#a3153e25cb4a1062d7b56bc10485c9ab8',1,'nr_send():&#160;krnl.c'],['../krnl_8h.html#a3153e25cb4a1062d7b56bc10485c9ab8',1,'nr_send():&#160;krnl.c']]],
  ['nr_5ftask',['nr_task',['../krnl_8c.html#adb04c7a4b69d0318cdfcf19f8bbdf2ec',1,'nr_task():&#160;krnl.c'],['../krnl_8h.html#adb04c7a4b69d0318cdfcf19f8bbdf2ec',1,'nr_task():&#160;krnl.c']]],
  ['nrclip',['nrClip',['../krnl_8h.html#ae4dc017f2c559a3c2460c69f0ead9dea',1,'krnl.h']]]
];
