var searchData=
[
  ['countmax',['COUNTMAX',['../krnl_8c.html#a5880ec0d5758fc1e5be1306456ed28b3',1,'krnl.c']]]
];
