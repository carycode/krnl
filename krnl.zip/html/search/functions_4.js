var searchData=
[
  ['freeram',['freeRam',['../krnl_8c.html#abde03a57484eac43bffbad24df5fc794',1,'freeRam(void):&#160;krnl.c'],['../krnl_8h.html#abde03a57484eac43bffbad24df5fc794',1,'freeRam(void):&#160;krnl.c']]]
];
