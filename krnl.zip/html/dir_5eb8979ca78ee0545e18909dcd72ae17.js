var dir_5eb8979ca78ee0545e18909dcd72ae17 =
[
    [ "semperf.ino", "semperf_8ino.html", "semperf_8ino" ]
];