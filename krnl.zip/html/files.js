var files =
[
    [ "examples", "dir_d28a4824dc47e487b107a5db32ef43c4.html", "dir_d28a4824dc47e487b107a5db32ef43c4" ],
    [ "krnl.c", "krnl_8c.html", "krnl_8c" ],
    [ "krnl.h", "krnl_8h.html", "krnl_8h" ],
    [ "mainpage.c", "mainpage_8c.html", null ]
];