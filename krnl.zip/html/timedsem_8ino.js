var timedsem_8ino =
[
    [ "doBlink", "timedsem_8ino.html#a324b3fb0f00dc6c117e43c2457b769df", null ],
    [ "loop", "timedsem_8ino.html#afe461d27b9c48d5921c00d521181f12f", null ],
    [ "setup", "timedsem_8ino.html#a4fc01d736fe50cf5b977f755b675f11d", null ],
    [ "t1", "timedsem_8ino.html#ac5c5136eb2c6e01ac014c723c5be421f", null ],
    [ "t2", "timedsem_8ino.html#a6771c53ff569217bf356d04e0ff969d8", null ],
    [ "pt1", "timedsem_8ino.html#a9a146d4b8415081193f1ae9fe2f9c58d", null ],
    [ "pt2", "timedsem_8ino.html#a813c0d40fcc55a88f597602c32aa7eca", null ],
    [ "s1", "timedsem_8ino.html#adbfeef45ba55e7ba16753279b13db36a", null ],
    [ "s2", "timedsem_8ino.html#ab28015e2e7d22927f95edd57e06c8bb1", null ],
    [ "sem1", "timedsem_8ino.html#a10808bb48fa0ad1f2cb5e2a020b5245e", null ],
    [ "sem2", "timedsem_8ino.html#ac088916aa4bcfb14f04db751728c361a", null ]
];